#include <stdio.h>
int main(){
 int numero;

printf("digite um numero: \n");
scanf("%d", &numero);

if (numero == 2) {
    printf("eh um numero primo.");
}
    else if (numero % 1 == 0 && numero % numero == 0 && numero % 2 != 0){

     printf("eh um numero primo.");
    }
    else{
        printf("nao eh numero primo");
        }

}