#include <stdio.h>

int main()
{
    int celsius, fahrenheit;
    char escolha;

    printf("Escolha a conversao desejada:\nC - Celsius\nF - Fahrenheit\n");
    scanf("%c", &escolha);

    switch (escolha)
    {
        case 'C':
            printf("Digite a temperatura em C: ");
            scanf("%d", &celsius);
            printf("A temperatura em F eh: %.1f\n", (celsius * 1.8) + 32);
            break;

        case 'F':
            printf("Digite a temperatura em F: ");
            scanf("%d", &fahrenheit);
            printf("A temperatura em C eh: %.1f\n", (fahrenheit - 32) * 5 / 9);
            break;

        default:
            printf("Opcao invalida.\n");
            break;
    }

    return 0;
}
