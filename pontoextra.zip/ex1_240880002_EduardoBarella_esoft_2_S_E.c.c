#include <stdio.h>
int main(){
    float valor,desc;

    printf("valor: \n");
    scanf("%f", &valor);

    if (valor > 100 && valor <= 500){

        desc = valor * 0.10;
        valor = valor - desc;
        printf("valor eh: %.2f", valor);

    }else if (valor > 500){

        desc = valor * 0.20;
        valor = valor - desc;
        printf("valor eh: %.2f",valor);

    }else{
        printf("valor sem desconto: %.2f",valor);
    }
}