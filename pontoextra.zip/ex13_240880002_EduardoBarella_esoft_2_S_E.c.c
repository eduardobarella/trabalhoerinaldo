#include <stdio.h>

int main() {
    int pontos;
    char nivel;

    printf("Digite a quantidade de pontos ganhos: ");
    scanf("%d", &pontos);

    if (pontos >= 1000) {
        nivel = 'A';
    } else if (pontos >= 500) {
        nivel = 'B';
    } else if (pontos >= 100) {
        nivel = 'C';
    } else {
        nivel = 'D';
    }

    printf("O nivel de premiacao e: %c\n", nivel);

    return 0;
}
