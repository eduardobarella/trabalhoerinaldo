#include <stdio.h>
int main(){
    int distancia;
    float consumo, p_gasolina;
    
    printf("qual foi a distancia percorrida em km?\n");
    scanf("%d", &distancia);
    
    printf("qual foi o consumo medio de gasolina?\n");
    scanf("%f", &consumo);

    printf("preco da gasolina\n");
    scanf("%f", &p_gasolina);

    printf("o preco da viagem eh: %.2f", ((float) distancia / consumo) * p_gasolina);


}