#include <stdio.h>
#include <math.h>

int main() {
    float valor_emprestimo, taxa_juros_anual, taxa_juros_mensal;
    int num_parcelas;
    float prestacao;

    printf("Digite o valor do emprestimo: ");
    scanf("%f", &valor_emprestimo);

    printf("Digite a taxa de juros anual (em porcentagem): ");
    scanf("%f", &taxa_juros_anual);

    printf("Digite o numero de parcelas: ");
    scanf("%d", &num_parcelas);

    taxa_juros_mensal = (taxa_juros_anual / 100) / 12;
    
    prestacao = valor_emprestimo * taxa_juros_mensal / (1 - pow(1 + taxa_juros_mensal, -num_parcelas));

    printf("O valor da prestacao mensal eh: R$ %.2f\n", prestacao);

    return 0;
}
