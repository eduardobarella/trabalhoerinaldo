#include <stdio.h>
#include <string.h>
#include <ctype.h>

int verificar_codigo(const char *codigo) {

    if (strlen(codigo) != 8) {
        return 0;
    }
    
    for (int i = 0; i < 8; i++) {
        if (!isdigit(codigo[i])) {
            return 0;
        }
    }
    
    return 1;
}

int main() {
    char codigo[20];
    
    printf("Digite o código da encomenda: ");
    scanf("%s", codigo);
    
    if (verificar_codigo(codigo)) {
        printf("Código válido \n");
    } else {
        printf("Código inválido, o código deve ter exatamente 8 dígitos.\n");
    }

    return 0;
}
