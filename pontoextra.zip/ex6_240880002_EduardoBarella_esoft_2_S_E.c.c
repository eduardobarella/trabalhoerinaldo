#include <locale.h>
#include <stdio.h>

int main()
{
    int quant, quant_p;
    float preco, desconto, total = 0;

    printf("Qual a quantidade de produtos unicos? ");
    scanf("%d", &quant);
    for (int i = 0; i < quant; i++)
    {
        printf("Digite o preco do %dº produto? ", i+1);
        scanf("%f", &preco);

        printf("Quantos foram comprados? ");
        scanf("%d", &quant_p);

        printf("Qual o desconto do produto ?\nDigite 0 para sem desconto.\n");
        scanf("%f", &desconto);

        preco = preco * quant_p;
        desconto = preco * desconto / 100;
        total += preco - desconto;
    }
    printf("O valor total da compra é de: %.2f", total);
    return 0;
}