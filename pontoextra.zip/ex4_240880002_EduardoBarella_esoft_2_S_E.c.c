#include <stdio.h>
#include <math.h> 

int main() {
    int numero, raiz;

    printf("Digite um numero: ");
    scanf("%d", &numero);

    raiz = sqrt(numero);

    if (raiz * raiz == numero) {
        printf("%d eh um quadrado perfeito.\n", numero);
    } else {
        printf("%d nao eh um quadrado perfeito.\n", numero);
    }

    return 0;
}
