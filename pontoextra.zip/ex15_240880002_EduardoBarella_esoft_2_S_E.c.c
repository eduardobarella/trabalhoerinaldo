#include <ctype.h>
#include <locale.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

int main() {
    setlocale(LC_ALL, "Portuguese");
    int tamanho = 0;
    char senha[40];
    bool maiusc = false, minusc = false, num = false, carac_e = false;

    printf("Digite uma senha: ");
    fgets(senha, sizeof(senha), stdin);
    
    senha[strcspn(senha, "\n")] = '\0';

    for (int i = 0; i < (int)strlen(senha); i++) {
        if (isupper(senha[i])) maiusc = true;
        if (islower(senha[i])) minusc = true;
        if (isdigit(senha[i])) num = true;
        if (!isalnum(senha[i])) carac_e = true;
        tamanho++;
    }

    if (tamanho >= 8 && maiusc && minusc && num && carac_e) {
        printf("Senha Válida.\n");
    } else {
        printf("Senha Inválida.\n");
    }

    return 0;
}
