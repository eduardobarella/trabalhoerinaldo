#include <stdio.h>

int main() {
    float salario, salario_final, bonus;
    char nota;


    printf("Digite o salario: ");
    scanf("%f", &salario);

    printf("Digite a nota: ");
    scanf(" %c", &nota);

    if (nota == 'a') {
        bonus = salario * 0.15;
    } else if (nota == 'b') {
        bonus = salario * 0.10;
    } else if (nota == 'c') {
        bonus = salario * 0.05;
    } else {
        bonus = 0;
    }

    salario_final = salario + bonus;

    printf("Salario final: %.2f\n", salario_final);

    return 0;
}
