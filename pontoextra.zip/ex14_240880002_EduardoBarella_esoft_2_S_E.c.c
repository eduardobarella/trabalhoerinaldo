#include <stdio.h>

int main() {
    int quantidade;
    char categoria;
    float preco_unitario, preco_total, desconto;

    printf("Digite o preço unitário do livro: ");
    scanf("%f", &preco_unitario);

    printf("Digite a quantidade de livros comprados: ");
    scanf("%d", &quantidade);

    printf("Digite a categoria do livro (A, B ou C): ");
    scanf(" %c", &categoria);

    if (quantidade >= 15) {
        desconto = 0.25;
    } else if (quantidade >= 10) {
        desconto = 0.15;
    } else if (quantidade >= 5) {
        desconto = 0.10;
    } else {
        desconto = 0.05;
    }

    if (categoria == 'A') {
        desconto += 0.10;
    } else if (categoria == 'B') {
        desconto += 0.07;
    } else if (categoria == 'C') {
        desconto += 0.04;
    }

    preco_total = preco_unitario * quantidade * (1 - desconto);

    printf("O preço total da compra é: %.2f\n", preco_total);

    return 0;
}
