#include <stdio.h>

int main() {
    float taxa_base, taxa_km, km_rodados, total;

    printf("Digite a taxa base do aluguel: ");
    scanf("%f", &taxa_base);

    printf("Digite a taxa por quilometro rodado: ");
    scanf("%f", &taxa_km);

    printf("Digite a quantidade de quilometros rodados: ");
    scanf("%f", &km_rodados);

    total = taxa_base + (taxa_km * km_rodados);

    printf("O valor total do aluguel e: R$ %.2f\n", total);

    return 0;
}
