#include <stdio.h>

int main() {
    int numero_secreto = 12; 
    int palpite, tentativas = 0;

    printf("Tente adivinhar o numero entre 1 e 100. Voce tem 10 tentativas.\n");
    
    while (tentativas < 10) {
        printf("Tentativa %d: ", tentativas + 1);
        scanf("%d", &palpite);

        tentativas++;

        if (palpite == numero_secreto) {

            printf("Acertou \n", tentativas);

        } else if (palpite > numero_secreto) {
            printf("o numero eh menor.\n");
        } else {
            printf("o numero eh maior.\n");
        }
    }

    if (tentativas == 10 && palpite != numero_secreto) {
        printf("Acabou as tentativas %d.\n", numero_secreto);
    }

    return 0;
}
