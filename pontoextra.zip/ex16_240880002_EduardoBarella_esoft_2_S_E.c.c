#include <locale.h>
#include <stdio.h>

int main() {
    setlocale(LC_ALL, "Portuguese");
    int tamanho;
    float valor;
    
    printf("Qual o tamanho do grupo? ");
    scanf("%d", &tamanho);
    
    printf("Insira o valor base do pacote: ");
    scanf("%f", &valor);

    if (tamanho > 15) {
        valor -= valor * 0.15; 
    } else if (tamanho > 10) {
        valor -= valor * 0.10;
    }

    printf("O valor total é de: %.2f\n", valor);

    return 0;
}
